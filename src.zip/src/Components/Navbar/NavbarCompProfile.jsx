import React from 'react';
import { Navbar, Nav, Container, NavDropdown, Form, Button } from 'react-bootstrap';
import './NavbarComp.css'
import AuthService from '../../LoginSignUp/services/auth.service';
import { SearchBar } from '../SearchBar';

export const NavbarCompProfile = ({loadUser, onRouteChange, setFilteredEvents, eventsList}) => {
  return (
    <Navbar bg="black fixed-top" variant="dark">
      <Container>
      <Navbar.Brand onClick={() => {onRouteChange('Home')}} href="#home" className="logo">TIX</Navbar.Brand>

        <SearchBar onRouteChange={onRouteChange} setFilteredEvents={setFilteredEvents} eventsList={eventsList}/>

       
        <Nav className="ms-auto underline-on-hover">
          <Nav.Link onClick={() => {onRouteChange('Home')}} href="#home">Home</Nav.Link>
          <NavDropdown title="Events" id="basic-nav-dropdown">
            <NavDropdown.Item 
            onClick={() => {onRouteChange('AllEvents')}}
            className="dropdownitem" href="#events-all">All</NavDropdown.Item>
            <NavDropdown.Item 
            onClick={() => {onRouteChange('Music')}}
            className="dropdownitem" href="#events-music">Music</NavDropdown.Item>
            <NavDropdown.Item  
            onClick={() => {onRouteChange('Sports')}}
            className="dropdownitem" href="#events-sports">Sports</NavDropdown.Item>
          </NavDropdown>
          <Nav.Link href="#FAQ">FAQ</Nav.Link>
        </Nav>

        <Nav className="ml-auto">
        <NavDropdown title="Profile" id="basic-nav-dropdown">
          <NavDropdown.Item 
          onClick={() => {
              onRouteChange('Profile')
          }}
          href="#profile">Profile</NavDropdown.Item>
          <NavDropdown.Item 
          onClick={() => {
              onRouteChange('UserPurchases')
          }}
          href="#purchase">Purchases</NavDropdown.Item>
          <NavDropdown.Item 
          onClick={() => {
            localStorage.removeItem("user");
            loadUser('','','');
            alert("You've successfully logged out");
            onRouteChange("Home");
          }}
          href="#signout">Sign Out</NavDropdown.Item>
        </NavDropdown>
        </Nav>
      </Container>
    </Navbar>
  );
}

export default NavbarCompProfile;
